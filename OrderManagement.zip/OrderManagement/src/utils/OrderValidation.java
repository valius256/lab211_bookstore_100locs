package utils;

import java.util.Date;

public class OrderValidation{
    private static final String Date_format = "mm/dd/yyyy";
    
    public static boolean checkOrderID(String Id) {
        if (Id.matches("[D]+\\d{3}")) {
            return true;
        }
        return false;
    }

    public static boolean checkOrderName(String Name) {
        if (Name.length() > 5 && Name.length() < 30) {
            return true;
        }

        return false;
    }

    public static boolean checOrdersPrice(double price) {
        if (price > 0) {
            return true;
        }
        return false;
    }   

    public static boolean checOrdersQuantity(int quantity) {
        if (quantity > 0) {
            return true;
        }
        return false;
    }

    public static boolean checkOrdersStatus(String Status) {
        if (Status.equals("Available") || Status.equals("Not Available")) {
            return true;
        }
        return false;
    }
    
    public static boolean checkOrderDate(String date){
        if (date.matches(Date_format)) {
            return true;
        }
        return false;
    }
    
    public static boolean validateDate(Date createDate, Date lastUpdateDate) {
        Date now = new Date();
        if (createDate == null) {
            return lastUpdateDate != null && !lastUpdateDate.after(now);
        } else if (lastUpdateDate == null) {
            return !createDate.after(now);
        }
        return !createDate.after(lastUpdateDate) && !lastUpdateDate.after(now);
    }
}